// src/components/Footer.jsx
import React from 'react';

const Footer = () => (
  <div className="footer text-center mt-5">© 2024 Yihan Hsieh</div>
);

export default Footer;
